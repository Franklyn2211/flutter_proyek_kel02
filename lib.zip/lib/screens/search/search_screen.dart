import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_proyek_kel02/screens/home/recipe_detail_page.dart';
import 'package:flutter_proyek_kel02/size_config.dart';

class SearchScreen extends StatefulWidget {
  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  TextEditingController searchController = TextEditingController();
  List<dynamic> recipes = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchRecipes();
  }

  // Fungsi untuk mengambil data resep dari Firestore
  Future<void> _fetchRecipes() async {
    try {
      QuerySnapshot snapshot =
          await FirebaseFirestore.instance.collection('recipes').get();
      setState(() {
        recipes = snapshot.docs.map((doc) => doc.data()).toList();
        isLoading = false;
      });
    } catch (e) {
      print("Error fetching recipes: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  // Fungsi untuk menyaring resep berdasarkan kata kunci pencarian
  List<dynamic> getSearchedRecipes() {
    String searchQuery = searchController.text.toLowerCase();
    if (searchQuery.isEmpty) {
      return recipes; // Jika tidak ada pencarian, tampilkan semua resep
    }
    return recipes
        .where((recipe) => recipe['name']
            .toLowerCase()
            .contains(searchQuery) || recipe['category']
            .toLowerCase()
            .contains(searchQuery)) // Mencocokkan nama atau kategori
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: AppBar(
        title: Text("Search Recipes"),
        backgroundColor: Color(0xFF90AF17),
      ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: SizeConfig.defaultSize * 2),
              child: TextField(
                controller: searchController,
                decoration: InputDecoration(
                  labelText: 'Search by name or category',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  setState(() {
                    isLoading = true;
                  });
                  // Ketika ada perubahan, refresh hasil pencarian
                  _fetchRecipes();
                },
              ),
            ),
            Expanded(
              child: isLoading
                  ? Center(child: CircularProgressIndicator())
                  : ListView.builder(
                      itemCount: getSearchedRecipes().length,
                      itemBuilder: (context, index) {
                        final recipe = getSearchedRecipes()[index];
                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    RecipeDetailPage(recipe: recipe),
                              ),
                            );
                          },
                          child: Card(
                            margin: EdgeInsets.symmetric(
                                vertical: SizeConfig.defaultSize),
                            child: ListTile(
                              title: Text(recipe['name']),
                              subtitle: Text(recipe['category']),
                              leading: Icon(Icons.food_bank),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
