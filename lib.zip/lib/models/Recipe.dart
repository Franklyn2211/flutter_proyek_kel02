// class Recipe {
//   final String name;
//   final String category;

//   Recipe({required this.name, required this.category});
// }